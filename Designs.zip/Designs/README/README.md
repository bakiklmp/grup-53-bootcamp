# GRIDFLARE OYUN TASARIMLARI

- Bu klasör, Google Yapay Zeka ve Teknoloji Akademisi kapsamında 1 aylık bootcamp sürecinde geliştirdiğimiz oyunun tasarım içeriklerini barındırmaktadır.

- Tasarımlar **Mehmet Tunahan Çanak** tarafından hazırlanmıştır.
E-Mail: tunahan.personal@gmail.com
Youtube: @tunaTheVoyager
Linkedin: Mehmet Tunahan Çanak
Github: github.com/TunatheVoyager
---

## Kullanım Hakkı

- Bu klasördeki tüm görselleri **ticari ya da ticari olmayan** projelerde **özgürce kullanabilirsiniz**
- **Kredi vermek** zorunlu değildir. Ancak tasarımları herhangi bir ürününüzde kullanırsanız, bana katkı olarak ismimi belirtirseniz çok mutlu olurum.

### Örnek Kredi Notu: 

Tasarım: Mehmet Tunahan Çanak (github.com/TunatheVoyager)

---

ÖNEMLİ NOT: **Tasarımları bireysel olarak satmaktan veya sahiplenmekten kaçınmanı rica ederim.**

- Ekip arkadaşım **Halit Bakihan Tokgöz'e** katkıları için teşekkür ederim. 


